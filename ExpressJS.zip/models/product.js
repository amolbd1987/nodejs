const mongodb = require('mongodb');
const getDb = require('../util/database').getDb;

class product {
    constructor(item){
        this.item = item;    
    }
    save() {
        const db = getDb();
        let dbOp = db.collection('product').insertOne(this);
        
        return dbOp
          .then(result => {
            console.log(result);
          })
          .catch(err => {
            console.log(err);
          });
    }
    
}
module.exports = product;