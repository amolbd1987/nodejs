const path = require('path');
const express = require('express');
const router = express.Router();
const productInfo = require('../models/product')
const getDb = require('../util/database').getDb;
// /admin/add-product => GET
router.get('/add-product', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../', 'views', 'add-product.html'));
});

// /admin/add-product => POST
router.post('/add-product', (req, res, next) => {
  console.log(req.body);
  const ProductInfo = new productInfo(req.body.title)
  ProductInfo
      .save()
      .then(result => {
        console.log('Created Product');        
        res.status(200).send('<h1>Product Added successfully<h1><li><a href="/listproduct">List Product</a></li>');
      })
      .catch(err => {
        console.log(err);
        res.status(400).send({'message':'Error'});
      });
  //res.redirect('/success');
});

// router.get('/success', (req, res, next) => {    
//     res.send('<h1>Product Added successfully</h1>');
//   });

router.get('/listproduct', (req, res, next) => {    

     //res.send('<h1>Product List</h1>');
     let htmlstr = '<html> <h1> Product List </h1>'
      const db = getDb();
      return db
        .collection('product')
        .find()
        .toArray()
        .then(result => {
          //console.log(result);
          result.forEach(el => {
            htmlstr = htmlstr +'<h4>'+el.item+'</h4>'
          });
          htmlstr = htmlstr + '</html> <li><a href="/add-product">Shop More</a></li>'
          console.log(htmlstr)
          res.status(200).send(htmlstr)
        })
        .catch(err => {
          console.log(err);
          res.status(404).send('Error')
        });
    
  });


module.exports = router;